default_app_config = 'timetable.apps.Config'
