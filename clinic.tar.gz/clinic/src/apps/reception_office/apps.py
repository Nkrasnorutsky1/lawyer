from django.apps import AppConfig


class Config(AppConfig):
    name = 'reception_office'
    verbose_name = 'Расписание'