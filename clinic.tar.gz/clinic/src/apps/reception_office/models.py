from django.db import models

from timetable.models import Timetable, WorkingHour
from users.models import Patient, Doctor


class Visit(models.Model):
    date = models.DateField(
        verbose_name='Дата консультации', null=True)
    visit_hour = models.ForeignKey(
        'timetable.WorkingHour', blank=True, null=True,
        verbose_name='Выбранный час')
    patient = models.ForeignKey(
        'users.Patient', blank=True, null=True, verbose_name='Клиент')
    doctor = models.ForeignKey(
        'users.Doctor', blank=True, null=True,  verbose_name='Юрист')

    def __str__(self):
        return '%s | на время: %s | принимает %s | %s' % (
            self.date.strftime('%d.%m.%Y'),
            self.visit_hour,
            self.doctor,
            self.patient
        )

    class Meta:
        verbose_name = 'Консультация'
        verbose_name_plural = 'Консультации'

