from django.apps import AppConfig


class Config(AppConfig):
    name = 'users'
    verbose_name = 'Пользователи'