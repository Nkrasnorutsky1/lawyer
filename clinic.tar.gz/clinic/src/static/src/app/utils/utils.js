angular.module('clinic.utils', [
  'dataService',
  'notifyingService',
  'pageTitleService',
]);
