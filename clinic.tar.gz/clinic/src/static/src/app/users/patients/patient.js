angular.module('patients', [
  'ReceptionController',
  'ui.router',
]);

