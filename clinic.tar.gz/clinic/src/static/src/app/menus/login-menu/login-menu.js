angular.module('login-menu', [
  'loginMenuDirective'
]);
