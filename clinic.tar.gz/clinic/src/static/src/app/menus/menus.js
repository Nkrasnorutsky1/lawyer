angular.module('clinic.menus', [
  'menuSettingsService',
  'date-input',
  'login-menu',
  'reception-button',
  'visits-link'
]);
