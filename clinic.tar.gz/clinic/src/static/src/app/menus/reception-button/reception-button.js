angular.module('reception-button', [
  'receptionButtonDirective'
]);
