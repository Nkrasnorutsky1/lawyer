angular.module('date-input', [
  'dateInputDirective'
]);
